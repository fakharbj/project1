/* Trinket Tales: small additions on top of Dawn. No dependencies. */
(() => {
  /* Delivery estimate: "Order today, arrives Wed 12 – Fri 14 Nov" (skips Sundays). */
  if (!customElements.get('tt-eta')) {
    customElements.define(
      'tt-eta',
      class TtEta extends HTMLElement {
        connectedCallback() {
          const min = parseInt(this.dataset.min, 10) || 3;
          const max = Math.max(parseInt(this.dataset.max, 10) || 5, min);
          const out = this.querySelector('[data-eta-dates]');
          if (!out) return;
          const addWorkingDays = (n) => {
            const d = new Date();
            let added = 0;
            while (added < n) {
              d.setDate(d.getDate() + 1);
              if (d.getDay() !== 0) added += 1;
            }
            return d;
          };
          const lang = document.documentElement.lang || 'en';
          const weekday = (d) => d.toLocaleDateString(lang, { weekday: 'short' });
          const month = (d) => d.toLocaleDateString(lang, { month: 'short' });
          const from = addWorkingDays(min);
          const to = addWorkingDays(max);
          const start = from.getMonth() === to.getMonth()
            ? `${weekday(from)} ${from.getDate()}`
            : `${weekday(from)} ${from.getDate()} ${month(from)}`;
          out.textContent = `${start} – ${weekday(to)} ${to.getDate()} ${month(to)}`;
        }
      }
    );
  }

  /* Sticky add to cart: mirrors the main product form and slides in once it scrolls away. */
  if (!customElements.get('tt-sticky-atc')) {
    customElements.define(
      'tt-sticky-atc',
      class TtStickyAtc extends HTMLElement {
        connectedCallback() {
          this.addButton = this.querySelector('[data-sticky-add]');
          this.priceEl = this.querySelector('[data-sticky-price]');
          this.variantEl = this.querySelector('[data-sticky-variant]');
          this.visible = false;
          this.ticking = false;
          this.onScroll = this.onScroll.bind(this);
          this.onChange = this.onChange.bind(this);

          this.addButton.addEventListener('click', () => {
            const main = this.mainButton();
            if (main && !main.disabled) {
              main.click();
            } else {
              const form = document.querySelector('product-info .product-form, product-info variant-selects');
              if (form) form.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
          });

          window.addEventListener('scroll', this.onScroll, { passive: true });
          window.addEventListener('resize', this.onScroll, { passive: true });
          document.addEventListener('change', this.onChange);
          if (typeof subscribe === 'function' && typeof PUB_SUB_EVENTS !== 'undefined') {
            this.unsubscribe = subscribe(PUB_SUB_EVENTS.variantChange, () => setTimeout(() => this.sync(), 50));
          }
          this.sync();
          this.onScroll();
        }

        disconnectedCallback() {
          window.removeEventListener('scroll', this.onScroll);
          window.removeEventListener('resize', this.onScroll);
          document.removeEventListener('change', this.onChange);
          if (this.unsubscribe) this.unsubscribe();
          document.body.classList.remove('tt-sticky-atc-on');
        }

        mainButton() {
          return document.querySelector('product-info .product-form__submit[name="add"]');
        }

        onChange(event) {
          if (event.target.closest('variant-selects')) setTimeout(() => this.sync(), 400);
        }

        onScroll() {
          if (this.ticking) return;
          this.ticking = true;
          requestAnimationFrame(() => {
            this.ticking = false;
            const main = this.mainButton();
            const show = !!main && main.getBoundingClientRect().bottom < 0;
            if (show === this.visible) return;
            this.visible = show;
            this.classList.toggle('is-visible', show);
            this.setAttribute('aria-hidden', String(!show));
            this.toggleAttribute('inert', !show);
            document.body.classList.toggle('tt-sticky-atc-on', show);
            if (show) this.sync();
          });
        }

        sync() {
          const main = this.mainButton();
          if (!main) return;
          this.addButton.disabled = main.disabled;
          const label = main.querySelector('span');
          const ownLabel = this.addButton.querySelector('span');
          if (label && ownLabel) ownLabel.textContent = label.textContent.trim();

          const price = document.querySelector('product-info [id^="price-"] .price');
          if (price && this.priceEl) {
            const current = price.classList.contains('price--on-sale')
              ? price.querySelector('.price__sale .price-item--last')
              : price.querySelector('.price__regular .price-item--regular');
            if (current && current.textContent.trim()) this.priceEl.textContent = current.textContent.trim();
          }

          if (this.variantEl) {
            const picked = [
              ...document.querySelectorAll('product-info variant-selects input[type="radio"]:checked'),
            ].map((input) => input.value);
            document.querySelectorAll('product-info variant-selects select').forEach((select) => {
              const option = select.options[select.selectedIndex];
              if (option) picked.push(option.textContent.trim());
            });
            if (picked.length) this.variantEl.textContent = picked.join(' / ');
          }
        }
      }
    );
  }
})();
